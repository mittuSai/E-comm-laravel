@extends('master')
@section('content')
<table class="table table-striped">
  
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Total Price</td>
      <td>{{$total}}</td>
      
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>tax</td>
      <td>0</td>
      
    </tr>
    <tr>
      <th scope="row">3</th>
      <td > delivery</td>
      <td>10</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td > Total</td>
      <td>₹ {{$total+10}} /-</td>
    </tr>
  </tbody>
</table>
<div class="container">
<form action="/placeorder" method="post">
    @csrf
  <div class="mb-3">
   
   <textarea name="address" id="" rows="2" cols="150"></textarea>
   <span style="color: red;">@error('address'){{$message}} @enderror</span>
    
  </div>
 
  <div class="mb-3 ">
  
    <input type="radio"value="cash" class="form-check-input" id="exampleCheck1" name="payment"><span>UPI</span><br>
    <input type="radio"value="cash" class="form-check-input" id="exampleCheck2" name="payment"><span>card</span><br>
 
    <input type="radio"value="cash" class="form-check-input" id="exampleCheck2" name="payment"><span>Cash On Delivery</span>
    
   
  </div>
  <div class="mb-3 form-check">

   
  </div>
  <button type="submit" class="btn btn-primary m-2">order now</button>
</form>
</div>
@endsection