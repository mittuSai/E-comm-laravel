@extends('master')
@section('content')

  
<section class="product-section">
@if ($count>0)
<div class="container g-5">
  <div class="row row-cols-3 g-5">

@foreach ($result as $item)
 <div class="card mb-3 col-12 col-md-4">
  <a href="/productdetails/{{$item['id']}}" style="text-decoration: none;">
  <img src="{{$item['image']}} " class="card-img-top" alt="..." style="height:150px;">
  <div class="card-body">
    <h5 class="card-title">{{$item['productname']}} </h5>
    <p class="card-text">{{$item['description']}} </p>
    <p class="card-text"><small class="text-muted"></small></p>
  </div>
  </a>
 
</div>
 
 @endforeach





  </div>
</div>
@else
   <div class="text-center">
      <h5>Sorry to say ...! </h5>
        <p>search something else</p>
   </div>


@endif
</section>


@endsection