@extends('master')
@section('content')
    <div class="container">
    <div class="card mb-3 col-12 ">
 
  <img src="{{$item->image}} " class="card-img-top" alt="..." style="height:450px; width:100%;">
  <div class="card-body text-center">
    <h5 class="card-title">{{$item->productname}} </h5>
    <p class="card-text">{{$item->description}} </p>
    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    <div class="row">
        <div class="col-6">
         <form action="/add_to_cart" method="post">
          @csrf
          <input type="hidden" name="product_id" value="{{$item->id}}">
         <button class="btn btn-success" type="submit">Add To Cart</button>
         </form></div>
        <div class="col-6"><button class="btn btn-success">Buy Now</button></div>
    </div>
  </div>
</div>



@endsection