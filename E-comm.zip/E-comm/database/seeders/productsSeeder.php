<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("products")->insert([
            'productname'=>'Bike (CNG)',
            'category'=>'automobile',
            'price'=>'95000',
            'description'=>'first cng bike lunched  in 2024',
            'image'=>'https://imgd.aeplcdn.com/664x374/n/cw/ec/1/versions/bajaj-cng-freedom-125-drum1720422266649.jpg?q=80' ]);
    }
}
