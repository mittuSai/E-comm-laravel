<?php

use App\Http\Controllers\productController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('master');
});
Route::get('/login', function () {
    return view('login');
});
Route::post('/login',[UserController::class,'login']);
Route::get('/products',[productController::class,'showingProducts']);
Route::get('productdetails/{id}',[productController::class,'productDetails']);
Route::get('search',[productController::class,'search']);
Route::view('/searchresults', 'search');
Route::post('/add_to_cart',[productController::class,'add_to_cart']);
Route::get('/logout',[UserController::class,'logout']);
Route::get('/cart',[productController::class,'cartList']);
Route::get('/removecart/{id}',[productController::class,'removeCart']);
Route::get('/ordernow',[productController::class,'orderNow']);
Route::post('/placeorder',[productController::class,'placeOrder']);
Route::get('/myorders',[productController::class,'myOrders']);
Route::post('/register',[UserController::class,'register'])->name('register');
Route::get('/signup',[UserController::class,'signup'])->name('signup');