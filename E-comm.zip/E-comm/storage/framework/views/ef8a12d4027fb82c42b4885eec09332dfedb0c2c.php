
<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="card mb-3 col-12 ">
 
  <img src="<?php echo e($item->image); ?> " class="card-img-top" alt="..." style="height:450px; width:100%;">
  <div class="card-body text-center">
    <h5 class="card-title"><?php echo e($item->productname); ?> </h5>
    <p class="card-text"><?php echo e($item->description); ?> </p>
    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    <div class="row">
        <div class="col-6">
         <form action="/add_to_cart" method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="product_id" value="<?php echo e($item->id); ?>">
         <button class="btn btn-success" type="submit">Add To Cart</button>
         </form></div>
        <div class="col-6"><button class="btn btn-success">Buy Now</button></div>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tut\E-comm\resources\views/productDetails.blade.php ENDPATH**/ ?>