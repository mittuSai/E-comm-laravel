
<?php $__env->startSection('content'); ?>
   <div class="container">
       
   <?php $__currentLoopData = $myorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="card mb-3 col-md-12" style="max-width: 100%;">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="<?php echo e($item->image); ?>" class="img-fluid rounded-start" alt="..." style="max-width:250px">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title"><?php echo e($item->productname); ?></h5>
        <p class="card-text"> <?php echo e($item->description); ?> </p>
        <p class="card-text"> <?php echo e($item->status); ?> </p>
        <p class="card-text"> <?php echo e($item->address); ?> </p>
        <p class="card-text"><small class="text-body-secondary">₹<?php echo e($item->price); ?></small></p>
        <div>
        
      </div>  
    </div>
     
    </div>
  </div>
</div>
   
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tut\E-comm\resources\views/myorders.blade.php ENDPATH**/ ?>