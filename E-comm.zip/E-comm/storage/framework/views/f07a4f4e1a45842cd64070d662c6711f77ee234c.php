
<?php $__env->startSection('content'); ?>

  <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators bg-dark">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="carousel-item <?php echo e($item['id']==1? 'active' :''); ?>">
      <img src="<?php echo e($item['image']); ?>" class="d-block w-100" alt="product images" style="height:550px;">
      <div class="carousel-caption d-none d-md-block " style="color:red;">
        <h5><?php echo e($item['productname']); ?></h5>
        <p><?php echo e($item['description']); ?></p>
        <span><?php echo e($item['price']); ?> </span>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </div>
  <button class="carousel-control-prev " type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<section class="product-section">

<div class="container gx-5">
  <div class="row row-cols-3 gx-2">
 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="card mb-3 col-12 col-md-3 mx-1 bg-warning">
  <a href="/productdetails/<?php echo e($item['id']); ?>" style="text-decoration: none;">
  <img src="<?php echo e($item['image']); ?> " class="card-img-top" alt="..." style="height:150px;">
  <div class="card-body">
    <h5 class="card-title"><?php echo e($item['productname']); ?> </h5>
    <p class="card-text"><?php echo e($item['description']); ?> </p>
    <p class="card-text"><small class="text-muted">₹ <?php echo e($item['price']); ?>/-</small></p>
  </div>
  </a>
</div>
 
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  </div>
</div>

</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tut\E-comm\resources\views/products.blade.php ENDPATH**/ ?>