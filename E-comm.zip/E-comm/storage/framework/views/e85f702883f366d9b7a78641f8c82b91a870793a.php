
<?php $__env->startSection('content'); ?>
<table class="table table-striped">
  
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Total Price</td>
      <td><?php echo e($total); ?></td>
      
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>tax</td>
      <td>0</td>
      
    </tr>
    <tr>
      <th scope="row">3</th>
      <td > delivery</td>
      <td>10</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td > Total</td>
      <td>₹ <?php echo e($total+10); ?> /-</td>
    </tr>
  </tbody>
</table>
<div class="container">
<form action="/placeorder" method="post">
    <?php echo csrf_field(); ?>
  <div class="mb-3">
   
   <textarea name="address" id="" rows="2" cols="150"></textarea>
   <span style="color: red;"><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
    
  </div>
 
  <div class="mb-3 ">
  
    <input type="radio"value="cash" class="form-check-input" id="exampleCheck1" name="payment"><span>UPI</span><br>
    <input type="radio"value="cash" class="form-check-input" id="exampleCheck2" name="payment"><span>card</span><br>
 
    <input type="radio"value="cash" class="form-check-input" id="exampleCheck2" name="payment"><span>Cash On Delivery</span>
    
   
  </div>
  <div class="mb-3 form-check">

   
  </div>
  <button type="submit" class="btn btn-primary m-2">order now</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tut\E-comm\resources\views/ordernow.blade.php ENDPATH**/ ?>