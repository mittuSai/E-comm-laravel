
<?php $__env->startSection('content'); ?>

  
<section class="product-section">
<?php if($count>0): ?>
<div class="container g-5">
  <div class="row row-cols-3 g-5">

<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="card mb-3 col-12 col-md-4">
  <a href="/productdetails/<?php echo e($item['id']); ?>" style="text-decoration: none;">
  <img src="<?php echo e($item['image']); ?> " class="card-img-top" alt="..." style="height:150px;">
  <div class="card-body">
    <h5 class="card-title"><?php echo e($item['productname']); ?> </h5>
    <p class="card-text"><?php echo e($item['description']); ?> </p>
    <p class="card-text"><small class="text-muted"></small></p>
  </div>
  </a>
 
</div>
 
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





  </div>
</div>
<?php else: ?>
   <div class="text-center">
      <h5>Sorry to say ...! </h5>
        <p>search something else</p>
   </div>


<?php endif; ?>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tut\E-comm\resources\views/search.blade.php ENDPATH**/ ?>