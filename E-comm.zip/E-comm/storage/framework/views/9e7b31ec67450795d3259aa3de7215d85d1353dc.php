
<?php $__env->startSection('content'); ?>
   <div class="container">
       <div class="text-center">
        <a href="/ordernow" class="btn btn-success m-5 "> Order Now</a>
       </div>
       <?php if($count>0): ?>
       <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="card mb-3 col-md-12" style="max-width: 100%;">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="<?php echo e($item->image); ?>" class="img-fluid rounded-start" alt="..." style="max-width:250px">
    </div>
        <div class="col-md-8">
           <div class="card-body">
              <h5 class="card-title"><?php echo e($item->productname); ?></h5>
              <p class="card-text"> <?php echo e($item->description); ?> </p>
              <p class="card-text"><small class="text-body-secondary">₹<?php echo e($item->price); ?></small></p>
              <div>
              <a href="removecart/<?php echo e($item->cart_id); ?>"><button class="btn btn-danger">remove</button></a>
          </div>  
         </div>
     
        </div>
      </div>
    </div>
   
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <div class="d-flex justify-content-center">
   <a href="/products" class="btn btn-primary m-4">Home</a>
   </div>
   <?php else: ?>
   <div class="text-center">
    <h5>Your cart is empty</h5>
   
    <a href="/products" class="btn btn-primary m-4">Home</a>
    
   </div>
   <?php endif; ?>
 

   </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_tut\E-comm\resources\views//cart.blade.php ENDPATH**/ ?>