<h1>
    <footer><div class="card">
  <div class=" text-center card-header">
   E-comm
  </div>
  <div class="card-body">
    <h5 class="card-title col-6">E-Commerce website</h5>

    <a href="/cart" class="btn btn-primary col-12">go to cart</a>
  </div>
</div>
    </footer>
</h1><?php /**PATH D:\laravel_tut\E-comm\resources\views/footer.blade.php ENDPATH**/ ?>