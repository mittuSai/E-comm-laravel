<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\product;
use App\Models\cart;
use App\Models\Order;
use Illuminate\Support\Facades\DB;
class productController extends Controller
{
    public function  showingProducts()
    {
            $productData=product::all();
            return view('products',['products'=>$productData]);
    }
    public function productDetails($id)
    {   
        $product= product::find($id);
        if ($product) {

            return view('productDetails', ['item'=>$product]);
        }
    }
    public function search(Request $request){
        $data= product::where('productname', 'like','%'.$request->input('search').'%')->get();
        $count=count($data); 
        return view('search', ['result'=>$data,'count'=>$count]); 
    }
    
    public function add_to_cart(Request $request){
      if($request->session()->has('user')){
      $cart =new Cart;
      $cart->user_id =$request->session()->get('id');
      $cart->product_id=$request->product_id;
      $cart->save();
      return redirect("cart");
   
      }
      else{
        return redirect("login");
      }
    }
    public static function cartItem(){
        $userid=session()->get('id');

        return Cart::where('user_id',$userid)->count();

    }
    public function cartList(){
        if (session()->has('user')) {
        $user=session()->get('id');
        $products=DB::table('cart')
        ->join('products','cart.Product_id','=','products.id')
        ->where('cart.user_id',$user)
        ->select('products.*','cart.id as cart_id')->get();
       $count=count($products);
        // return $count;
     
         return view('/cart',['product'=>$products,'count'=>$count]);
           
        }
        else{
            return redirect("/");
        }



    }
    function removeCart($id){

        Cart::destroy($id);
        return redirect('/cart');

    }
    function orderNow(){
        $user=session()->get('id');
        $total=DB::table('cart')
        ->join('products','cart.Product_id','=','products.id')
        ->where('cart.user_id',$user)
        ->select('products.*','cart.id as cart_id')->sum("products.price");
        if($total==0){
            return redirect("/cart");

        }
        else{
            return view("ordernow",["total"=>$total]);
        }
    }
    function placeOrder(Request $request){
        $request->validate([
                'address'=> 'required'
        ]);

        $user=session()->get('id');
        $allCart= Cart::where('user_id',$user)->get();
       
        foreach ($allCart as $cart) {
            $order =new Order();
           $order->product_id=$cart['product_id'];
           $order->user_id=$cart['user_id'];
           $order->status="pending";
           $order->payment_method=$request->payment;
           $order->payement_status="pending";
           $order->address=$request->address;
           $order->save();
           Cart::where('user_id',$user)->delete();

        }
      return redirect('/products');
    }
    function myOrders(){
        $user=session()->get('id');
        $myorders= DB::table('orders')
        ->join('products','orders.product_id','=','product_id')
        ->where('orders.user_id',$user)
        ->select('products.*','orders.*')->get();
        //  return $myorders;
        return view('myorders',['myorders'=>$myorders]);
    }
}
