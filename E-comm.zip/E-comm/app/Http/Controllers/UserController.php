<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
Use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\validation;
use PharIo\Manifest\Email;
class UserController extends Controller
{
    function signup(){
        return view("register");
      }
    public function register(Request $request) {
      
    //   $request->input();
    //   $request->all();
    
        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required|min:6',
            
        ]);
         $user=new User;
         $user->name=$request->name;
         $user->email=$request->email;
         $password=$request->password;
         $hashedpassword=Hash::make($password);
         $user->password=$hashedpassword;

         $user->save();

        return redirect('/login');
   
    }
    
    public function login(Request $req){
        $user=User::where(['email'=>$req->email])->first();
        
        if (!$user|| !Hash::check($req->password,$user->password)) {
            return redirect("/login");
        }
        else{
            session()->put('user', $user['name']);
            session()->put('id', $user['id']);
            
            
           return redirect("products");
        }
    }
    public function logout(Request $req){
        if (session()->has('user')) {
            session()->remove('user');
            return redirect('/products');
           
        }
        else{
            return redirect('login');
        }
    }
}
